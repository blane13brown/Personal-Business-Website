import React from 'react';
import './hero.css';
import drone from './images/DCS.png';

const Hero = () => {
    return (
        <div className='hero'>
            <div className="skew-box">
            </div>
            <div className="grid-box">
                <div className='hero-content'>
                    <h1>Professional and affordable drone services </h1>
                    <p>Droning Over Texas is offering drone services for Realators, Construction Managers, Weddings, and so much more. With drones, the sky is the limit!</p>
                    <a href="#">Find Out More</a>
                    <img src={drone} />
                </div>
            </div>
        </div>
    )
}

export default Hero