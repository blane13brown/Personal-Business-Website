import React from 'react'
import './section1.css'

const Section1 = () => {
    return (
        <section>
        </section>
    )
}

export default Section1