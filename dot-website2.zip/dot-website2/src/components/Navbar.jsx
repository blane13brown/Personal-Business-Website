import React from 'react';
import { Component } from 'react';
import logo from './images/dot_logo.svg';
import './navbar.css';

class Navbar extends Component {
    state = { clicked: false };
    handleClick = () => {
        this.setState({ clicked: !this.state.clicked })
    }
    render() {
        return (
            <div className="grid-box" >
                <div className='navbar'>
                    <img src={logo} alt="Droning over Texas logo" />
                    <div className='menu-btn' onClick={this.handleClick}>
                        <i id='menu-icon' className={this.state.clicked ? "fa-solid fa-xmark" : "fa-solid fa-bars"}></i>
                    </div>
                    <nav id="nav" className={this.state.clicked ? "#nav" : "#nav inactive"}>
                        <ul>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Services</a></li>
                            <li><a href="#">Gallery</a></li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                    </nav>
                    <ul className='social-links'>
                        <a href="#"><li><i class="fab fa-twitter"></i></li></a>
                        <a href="#"><li><i class="fa-brands fa-linkedin-in"></i></li></a>
                        <a href="#"><li><i class="fa-brands fa-facebook-f"></i></li></a>
                    </ul>
                </div>
            </div >
        )
    }
}

export default Navbar