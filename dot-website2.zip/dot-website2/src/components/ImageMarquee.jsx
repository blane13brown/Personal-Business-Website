import React from 'react'
import house1 from './images/house1.png';
import house2 from './images/house2.png';
import house3 from './images/house3.png';
import house4 from './images/house4.png';
import './imagemarquee.css';

const ImageMarquee = () => {
    return (
        <div className="marquee-bg">
            <div className="marquee-container">
                <div className='image-marquee'>
                    <ul>
                        <li><img src={house1} /></li>
                        <li><img src={house2} /></li>
                        <li><img src={house3} /></li>
                        <li><img src={house4} /></li>
                        <li><img src={house1} /></li>
                        <li><img src={house2} /></li>
                        <li><img src={house3} /></li>
                        <li><img src={house4} /></li>
                        <li><img src={house1} /></li>
                        <li><img src={house2} /></li>
                        <li><img src={house3} /></li>
                        <li><img src={house4} /></li>
                        <li><img src={house1} /></li>
                        <li><img src={house2} /></li>
                        <li><img src={house3} /></li>
                        <li><img src={house4} /></li>
                    </ul>
                </div>
            </div>
        </div>
    )
}

export default ImageMarquee