import Navbar from './components/Navbar.jsx';
import Hero from './components/Hero.jsx';
import Section1 from './components/Section1.jsx';
import ImageMarquee from './components/ImageMarquee.jsx';

function App() {

  return (
    <div className="container">
      <div className='hero-section'>
        <Navbar />
        <ImageMarquee />
        <Hero />
      </div>
    </div>
  )
}

export default App
